import pygame
import os

def play_music(file_path):
    pygame.mixer.init()
    pygame.mixer.music.load(file_path)
    pygame.mixer.music.play()

def pause_music():
    pygame.mixer.music.pause()

def unpause_music():
    pygame.mixer.music.unpause()

def forward_music():
    current_pos = pygame.mixer.music.get_pos() / 1000  # Convert to seconds
    forward_time = current_pos + 10
    pygame.mixer.music.set_pos(forward_time)

def main():
    print("Simple Music Player in Python using Pygame")
    print("Enter 'exit' to quit the program.")
    print("Developer Name : Kanishka singh ")
    
    while True:
        file_path = input("Enter the location to the music file: ")
        
        if file_path.lower() == 'exit':
            break
        
        if not os.path.exists(file_path):
            print("File not found. Please enter a valid file Location.")
            continue
        
        try:
            play_music(file_path)
            
            while pygame.mixer.music.get_busy():
                command = input("Enter 'pause' to pause, 'play' to ,play 'forward' to skip 10 seconds, or 'exit' to stop the music: ")
        
                if command.lower() == 'pause':
                    pause_music()
                elif command.lower() == 'unpause':
                    unpause_music()
                elif command.lower() == 'forward':
                    forward_music()
                elif command.lower() == 'exit':
                    pygame.mixer.music.stop()
                    break
        except Exception as e:
            print("An error occurred:", e)

if __name__ == "__main__":
    main()
